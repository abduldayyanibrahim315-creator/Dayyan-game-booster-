# Dayyan Game Booster — Android V1

A native Kotlin + Jetpack Compose Android app focused on CODM session detection and honest device diagnostics.

## V1 features

- User-started foreground monitoring service with a persistent notification.
- CODM foreground detection using Android Usage Access (`com.activision.callofduty.shooter`).
- Optional Do Not Disturb during detected CODM sessions, with the previous interruption filter saved and restored when the game leaves the foreground or monitoring stops.
- System-wide available RAM and low-memory status.
- Android thermal status (status level only; not a temperature reading).
- Network transport and Android's validated-internet status (not a live ping measurement).
- Shortcuts to launch CODM and review apps using Android Settings.
- Dark UI with green accents.

## Build

The included `gradlew` bootstrap script downloads the official Gradle 8.9 distribution if it is not already cached, then executes the requested Gradle task. Java 17 is required.

```bash
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## First launch on the phone

1. Install the debug APK.
2. Open Dayyan Game Booster and grant Usage Access in Android Settings.
3. Start Gaming Focus, then launch CODM from the app.
4. Optionally grant Notification Policy access and enable DND while CODM is active.
5. Stop monitoring after gaming. The app attempts to restore the previous DND interruption filter.

## Important Android limits

- An ordinary third-party app cannot freely force-stop other apps or reserve all RAM/CPU/GPU for CODM. The background-app button opens Android's app-management settings instead of killing processes.
- This app does not claim to read CODM's private FPS/GPU counters. Android's public APIs do not expose those game-internal measurements to an ordinary app.
- This V1 does not include a floating overlay, automatic thermal throttling control, live ping, or a guaranteed FPS boost.
- The monitoring service uses Android's `specialUse` foreground-service type. Distribution through Google Play may require additional declaration and review; this project is intended for controlled testing/sideloading first.
