package com.dayyan.gamebooster.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.dayyan.gamebooster.engine.DeviceDiagnostics
import com.dayyan.gamebooster.engine.GamingFocusController

class GameMonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val preferences by lazy {
        getSharedPreferences("dayyan_gaming_focus", MODE_PRIVATE)
    }

    private val monitorTask = object : Runnable {
        override fun run() {
            val codmForeground = DeviceDiagnostics.isCodmForeground(this@GameMonitorService)
            val snapshot = DeviceDiagnostics.snapshot(this@GameMonitorService)

            preferences.edit()
                .putBoolean("codm_foreground", codmForeground)
                .putLong("available_ram_mb", snapshot.availableRamMb)
                .putLong("total_ram_mb", snapshot.totalRamMb)
                .putInt("memory_pressure_percent", snapshot.memoryPressurePercent)
                .putBoolean("low_memory", snapshot.lowMemory)
                .putString("thermal_label", snapshot.thermalLabel)
                .putString("network_label", snapshot.networkLabel)
                .putBoolean("internet_validated", snapshot.internetValidated)
                .putLong("last_check_ms", System.currentTimeMillis())
                .apply()

            if (GamingFocusController.isAutoDndEnabled(this@GameMonitorService) && codmForeground) {
                GamingFocusController.applyDnd(this@GameMonitorService)
            } else {
                GamingFocusController.restoreDnd(this@GameMonitorService)
            }

            updateNotification(codmForeground, snapshot.availableRamMb, snapshot.thermalLabel)
            handler.postDelayed(this, MONITOR_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification(false, null, null)
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        handler.removeCallbacks(monitorTask)
        handler.post(monitorTask)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(monitorTask)
        GamingFocusController.restoreDnd(this)
        preferences.edit().putBoolean("monitoring_active", false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateNotification(codm: Boolean, availableRamMb: Long, thermal: String) {
        preferences.edit().putBoolean("monitoring_active", true).apply()
        val notification = buildNotification(codm, availableRamMb, thermal)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(codm: Boolean, availableRamMb: Long?, thermal: String?): Notification {
        val status = when {
            codm -> "CODM detected — Gaming Focus monitoring"
            !DeviceDiagnostics.hasUsageAccess(this) -> "Monitoring active — grant Usage Access to detect CODM"
            else -> "Waiting for Call of Duty: Mobile"
        }
        val details = if (availableRamMb == null || thermal == null) {
            "Device diagnostics are running"
        } else {
            "Available RAM: " + availableRamMb + " MB · Thermal: " + thermal
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Dayyan Game Booster")
            .setContentText(status)
            .setStyle(NotificationCompat.BigTextStyle().bigText(status + "\n" + details))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Gaming Focus monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Visible status for a user-started gaming monitoring session"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val ACTION_START = "com.dayyan.gamebooster.action.START_MONITORING"
        const val ACTION_STOP = "com.dayyan.gamebooster.action.STOP_MONITORING"
        private const val CHANNEL_ID = "dayyan_gaming_focus"
        private const val NOTIFICATION_ID = 4102
        private const val MONITOR_INTERVAL_MS = 5000L
    }
}
