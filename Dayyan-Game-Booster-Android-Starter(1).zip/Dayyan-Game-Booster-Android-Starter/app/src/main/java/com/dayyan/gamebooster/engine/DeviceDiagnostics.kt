package com.dayyan.gamebooster.engine

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.PowerManager
import android.os.Build
import android.os.Process
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager

const val CODM_PACKAGE = "com.activision.callofduty.shooter"

data class DeviceSnapshot(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val memoryPressurePercent: Int,
    val lowMemory: Boolean,
    val thermalLabel: String,
    val networkLabel: String,
    val internetValidated: Boolean
)

object DeviceDiagnostics {
    fun snapshot(context: Context): DeviceSnapshot {
        val activityManager = context.getSystemService(ActivityManager::class.java)
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)

        val totalMb = (memory.totalMem / (1024L * 1024L)).coerceAtLeast(1L)
        val availableMb = memory.availMem / (1024L * 1024L)
        val pressure = (((totalMb - availableMb).coerceAtLeast(0L) * 100L) / totalMb)
            .toInt().coerceIn(0, 100)

        val thermal = readThermalStatus(context)
        val network = readNetworkStatus(context)

        return DeviceSnapshot(
            totalRamMb = totalMb,
            availableRamMb = availableMb,
            memoryPressurePercent = pressure,
            lowMemory = memory.lowMemory,
            thermalLabel = thermal,
            networkLabel = network.first,
            internetValidated = network.second
        )
    }

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(AppOpsManager::class.java)
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun isCodmForeground(context: Context): Boolean {
        if (!hasUsageAccess(context)) return false
        val usageManager = context.getSystemService(UsageStatsManager::class.java)
        val end = System.currentTimeMillis()
        // Read a generous window so a game that has remained open is still detected.
        val events = usageManager.queryEvents(end - 6L * 60L * 60L * 1000L, end)
        val event = UsageEvents.Event()
        var foregroundPackage = ""

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val resumed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                    event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            } else {
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            val paused = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_PAUSED ||
                    event.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            } else {
                event.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            }

            if (resumed) foregroundPackage = event.packageName ?: ""
            if (paused && foregroundPackage == event.packageName) foregroundPackage = ""
        }
        return foregroundPackage == CODM_PACKAGE
    }

    private fun readThermalStatus(context: Context): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Unavailable on this Android version"
        val powerManager = context.getSystemService(PowerManager::class.java)
        return try {
            when (powerManager.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown risk"
                else -> "Unavailable"
            }
        } catch (_: Exception) {
            "Unavailable on this Android version"
        }
    }

    private fun readNetworkStatus(context: Context): Pair<String, Boolean> {
        val manager = context.getSystemService(ConnectivityManager::class.java)
        val network = manager.activeNetwork ?: return "No active network" to false
        val caps = manager.getNetworkCapabilities(network) ?: return "Network status unavailable" to false
        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other network"
        }
        return type to caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
