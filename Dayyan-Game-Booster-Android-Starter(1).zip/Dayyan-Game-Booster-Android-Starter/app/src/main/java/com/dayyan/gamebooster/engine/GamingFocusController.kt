package com.dayyan.gamebooster.engine

import android.app.NotificationManager
import android.content.Context

object GamingFocusController {
    private const val PREFS = "dayyan_gaming_focus"
    private const val KEY_AUTO_DND = "auto_dnd_enabled"
    private const val KEY_DND_APPLIED = "dnd_applied"
    private const val KEY_PREVIOUS_FILTER = "previous_interruption_filter"

    fun isAutoDndEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_DND, false)

    fun setAutoDndEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_DND, enabled).apply()
        if (!enabled) restoreDnd(context)
    }

    fun hasDndAccess(context: Context): Boolean =
        context.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun applyDnd(context: Context): Boolean {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (!manager.isNotificationPolicyAccessGranted) return false

        val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!preferences.getBoolean(KEY_DND_APPLIED, false)) {
            preferences.edit()
                .putInt(KEY_PREVIOUS_FILTER, manager.currentInterruptionFilter)
                .putBoolean(KEY_DND_APPLIED, true)
                .apply()
        }
        manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        return true
    }

    fun restoreDnd(context: Context) {
        val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!preferences.getBoolean(KEY_DND_APPLIED, false)) return

        val manager = context.getSystemService(NotificationManager::class.java)
        // Keep the saved state if access was revoked, so restoration can be retried
        // after the user grants Notification Policy access again.
        if (!manager.isNotificationPolicyAccessGranted) return

        val previous = preferences.getInt(
            KEY_PREVIOUS_FILTER,
            NotificationManager.INTERRUPTION_FILTER_ALL
        )
        manager.setInterruptionFilter(previous)
        preferences.edit().putBoolean(KEY_DND_APPLIED, false).apply()
    }
}
