package com.dayyan.gamebooster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.dayyan.gamebooster.engine.DeviceDiagnostics
import com.dayyan.gamebooster.engine.DeviceSnapshot
import com.dayyan.gamebooster.engine.GamingFocusController
import com.dayyan.gamebooster.engine.CODM_PACKAGE
import com.dayyan.gamebooster.service.GameMonitorService
import kotlinx.coroutines.delay

private val Background = Color(0xFF080C0A)
private val Panel = Color(0xFF121B17)
private val PanelRaised = Color(0xFF19251F)
private val Accent = Color(0xFF39D98A)
private val Muted = Color(0xFFA7B8AF)
private val White = Color(0xFFF4F8F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DayyanTheme {
                BoosterDashboard()
            }
        }
    }
}

@Composable
private fun DayyanTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF062015),
        secondary = Color(0xFF85E7B4),
        background = Background,
        surface = Panel,
        onBackground = White,
        onSurface = White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun BoosterDashboard() {
    val context = LocalContext.current
    val activity = context as Activity
    val preferences = remember {
        context.getSharedPreferences("dayyan_gaming_focus", Activity.MODE_PRIVATE)
    }

    var snapshot by remember { mutableStateOf(DeviceDiagnostics.snapshot(context)) }
    var usageGranted by remember { mutableStateOf(DeviceDiagnostics.hasUsageAccess(context)) }
    var dndGranted by remember { mutableStateOf(GamingFocusController.hasDndAccess(context)) }
    var autoDnd by remember { mutableStateOf(GamingFocusController.isAutoDndEnabled(context)) }
    var monitoring by remember { mutableStateOf(preferences.getBoolean("monitoring_active", false)) }
    var codmForeground by remember { mutableStateOf(preferences.getBoolean("codm_foreground", false)) }
    var notice by remember { mutableStateOf("Start a session before opening CODM for automatic detection.") }

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        usageGranted = DeviceDiagnostics.hasUsageAccess(context)
        dndGranted = GamingFocusController.hasDndAccess(context)
    }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) notice = "Notifications are disabled. Android may still show the active service in its system task controls."
    }

    LaunchedEffect(Unit) {
        while (true) {
            snapshot = DeviceDiagnostics.snapshot(context)
            usageGranted = DeviceDiagnostics.hasUsageAccess(context)
            dndGranted = GamingFocusController.hasDndAccess(context)
            autoDnd = GamingFocusController.isAutoDndEnabled(context)
            monitoring = preferences.getBoolean("monitoring_active", false)
            codmForeground = preferences.getBoolean("codm_foreground", false)
            delay(2000)
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .width(44.dp)
                        .height(44.dp)
                        .background(PanelRaised, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("DG", color = Accent, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("DAYYAN", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
                    Text("GAME BOOSTER", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                }
                Text("V1.0", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PanelRaised)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("GAMING FOCUS", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                    Text(
                        if (codmForeground) "Call of Duty: Mobile detected" else if (monitoring) "Waiting for CODM" else "Ready for your next match",
                        color = White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (monitoring) "The monitoring service is active." else "Start monitoring before launching CODM.",
                        color = Muted,
                        fontSize = 13.sp
                    )
                    Button(
                        onClick = {
                            if (!usageGranted) {
                                notice = "Allow Usage Access for Dayyan Game Booster, then return and start monitoring."
                                settingsLauncher.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                            } else {
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                ContextCompat.startForegroundService(context, Intent(context, GameMonitorService::class.java))
                                monitoring = true
                                notice = "Monitoring started. You can now launch CODM."
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF062015))
                    ) {
                        Text(if (monitoring) "RESTART MONITORING" else if (usageGranted) "START GAMING FOCUS" else "GRANT USAGE ACCESS", fontWeight = FontWeight.ExtraBold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                context.stopService(Intent(context, GameMonitorService::class.java))
                                monitoring = false
                                codmForeground = false
                                notice = "Monitoring stopped. Previous DND setting will be restored."
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = White)
                        ) { Text("STOP") }
                        Button(
                            onClick = {
                                val launch = context.packageManager.getLaunchIntentForPackage(CODM_PACKAGE)
                                if (launch != null) context.startActivity(launch)
                                else notice = "CODM was not found. Install the game or open it manually."
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = White)
                        ) { Text("OPEN CODM") }
                    }
                }
            }

            Text("DEVICE DIAGNOSTICS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MetricCard(
                    title = "AVAILABLE RAM",
                    value = formatMb(snapshot.availableRamMb),
                    detail = "of " + formatMb(snapshot.totalRamMb) + " system memory",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "MEMORY STATUS",
                    value = when {
                        snapshot.lowMemory -> "Low"
                        snapshot.memoryPressurePercent >= 88 -> "High pressure"
                        snapshot.memoryPressurePercent >= 75 -> "Elevated"
                        else -> "Normal"
                    },
                    detail = "System-wide estimate, not CODM-only RAM",
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MetricCard(
                    title = "THERMAL STATUS",
                    value = snapshot.thermalLabel,
                    detail = "Android thermal status",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "NETWORK",
                    value = snapshot.networkLabel,
                    detail = if (snapshot.internetValidated) "Internet validated" else "Internet not confirmed",
                    modifier = Modifier.weight(1f)
                )
            }

            Text("SMART BACKGROUND MANAGEMENT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Automatic interruption control", color = White, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("DND while CODM is active", color = White, fontSize = 14.sp)
                            Text(
                                if (dndGranted) "Permission granted" else "Notification Policy access required",
                                color = Muted,
                                fontSize = 12.sp
                            )
                        }
                        Switch(
                            checked = autoDnd,
                            onCheckedChange = { enabled ->
                                if (enabled && !dndGranted) {
                                    notice = "Allow Notification Policy access, then enable this option again."
                                    settingsLauncher.launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                                } else {
                                    GamingFocusController.setAutoDndEnabled(context, enabled)
                                    autoDnd = enabled
                                    notice = if (enabled) "DND will apply while CODM is detected." else "Automatic DND disabled."
                                }
                            }
                        )
                    }
                    Button(
                        onClick = { settingsLauncher.launch(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PanelRaised, contentColor = White)
                    ) { Text("REVIEW BACKGROUND APPS IN ANDROID SETTINGS") }
                    Text(
                        "Android does not let ordinary apps force-stop every other app. Review optional apps using Android's own settings; Dayyan will not kill system processes.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                }
            }

            Text("PERMISSIONS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PermissionRow("Usage Access", usageGranted) {
                        settingsLauncher.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    PermissionRow("Notification Policy", dndGranted) {
                        settingsLauncher.launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                }
            }

            if (notice.isNotBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(14.dp)) {
                    Text(notice, modifier = Modifier.padding(14.dp), color = Muted, fontSize = 12.sp)
                }
            }

            Text("V1 LIMITATIONS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(
                "This version reports system memory, Android thermal status, and network connectivity. It does not read CODM's private GPU/FPS counters, display a live ping measurement, force CPU/GPU clocks, or promise higher FPS. Those require separate measurement and device support.",
                color = Muted,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            Text(value, color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun PermissionRow(label: String, granted: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = White, fontWeight = FontWeight.SemiBold)
            Text(if (granted) "Enabled" else "Required for this feature", color = Muted, fontSize = 11.sp)
        }
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = PanelRaised, contentColor = if (granted) Accent else White)
        ) {
            Text(if (granted) "MANAGE" else "ALLOW", fontSize = 11.sp)
        }
    }
}

private fun formatMb(value: Long): String = if (value >= 1024L) {
    String.format("%.1f GB", value / 1024.0)
} else {
    "$value MB"
}
