@echo off
setlocal
set "GRADLE_VERSION=8.13"
set "GRADLE_SHA256=20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78"
set "GRADLE_HOME_DIR=%USERPROFILE%\.gradle\dayyan-wrapper"
set "GRADLE_INSTALL_DIR=%GRADLE_HOME_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%GRADLE_HOME_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
if exist "%GRADLE_INSTALL_DIR%\bin\gradle.bat" goto run_gradle
if not exist "%GRADLE_HOME_DIR%" mkdir "%GRADLE_HOME_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; if (!(Test-Path '%GRADLE_ZIP%')) { Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%' }; $actual=(Get-FileHash '%GRADLE_ZIP%' -Algorithm SHA256).Hash.ToLowerInvariant(); if ($actual -ne '%GRADLE_SHA256%') { Remove-Item '%GRADLE_ZIP%' -Force; throw 'Gradle download checksum mismatch.' }; Expand-Archive -Path '%GRADLE_ZIP%' -DestinationPath '%GRADLE_HOME_DIR%' -Force"
if errorlevel 1 exit /b 1
:run_gradle
call "%GRADLE_INSTALL_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
