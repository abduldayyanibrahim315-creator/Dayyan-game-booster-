package com.dayyan.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

private val AppBackground = Color(0xFF080C14)
private val Panel = Color(0xFF121B2A)
private val PanelRaised = Color(0xFF192538)
private val Mint = Color(0xFF59E6B5)
private val TextPrimary = Color(0xFFF3F7FB)
private val TextSecondary = Color(0xFF9BAABD)
private val Warning = Color(0xFFFFC46B)
private const val CODM_PACKAGE = "com.activision.callofduty.shooter"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                DayyanGameBoosterApp(
                    readStatus = { readDeviceStatus() },
                    launchCodm = { launchCallOfDuty() }
                )
            }
        }
    }

    private fun readDeviceStatus(): DeviceStatus {
        val batteryFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(null, batteryFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(null, batteryFilter)
        }
        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val rawBattery = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val batteryLevel = if (rawBattery in 0..100) rawBattery else {
            val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) (level * 100) / scale else -1
        }

        val rawTemperature = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val batteryTemperature = if (rawTemperature >= 0) {
            String.format(Locale.US, "%.1f °C", rawTemperature / 10f)
        } else {
            "Unavailable"
        }

        val batteryState = when (batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "On battery"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "Unknown"
        }

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connectivityManager.activeNetwork
        val capabilities = activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
        val networkType = when {
            capabilities == null -> "Offline"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN connection"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
        val internetStatus = when {
            capabilities == null -> "No active network"
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) -> "Internet validated"
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> "Network present; internet not verified"
            else -> "Internet unavailable or restricted"
        }

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            thermalLabel(powerManager.currentThermalStatus)
        } else {
            "Unavailable on this Android version"
        }

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)
        val availableRam = memory.availMem / (1024f * 1024f * 1024f)
        val totalRam = memory.totalMem / (1024f * 1024f * 1024f)

        @Suppress("DEPRECATION")
        val refreshRate = windowManager.defaultDisplay.refreshRate
        val codmInstalled = packageManager.getLaunchIntentForPackage(CODM_PACKAGE) != null

        return DeviceStatus(
            batteryPercent = batteryLevel,
            batteryState = batteryState,
            batteryTemperature = batteryTemperature,
            networkType = networkType,
            internetStatus = internetStatus,
            thermalStatus = thermal,
            availableRamGb = availableRam,
            totalRamGb = totalRam,
            displayRefreshRate = refreshRate,
            deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            codmInstalled = codmInstalled
        )
    }

    private fun launchCallOfDuty() {
        val launchIntent = packageManager.getLaunchIntentForPackage(CODM_PACKAGE)
        if (launchIntent == null) {
            Toast.makeText(this, "Call of Duty: Mobile was not found on this phone.", Toast.LENGTH_LONG).show()
        } else {
            startActivity(launchIntent)
        }
    }
}

internal data class DeviceStatus(
    val batteryPercent: Int,
    val batteryState: String,
    val batteryTemperature: String,
    val networkType: String,
    val internetStatus: String,
    val thermalStatus: String,
    val availableRamGb: Float,
    val totalRamGb: Float,
    val displayRefreshRate: Float,
    val deviceName: String,
    val androidVersion: String,
    val codmInstalled: Boolean
)

internal fun thermalLabel(status: Int): String = when (status) {
    PowerManager.THERMAL_STATUS_NONE -> "Normal"
    PowerManager.THERMAL_STATUS_LIGHT -> "Light"
    PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
    PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
    PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
    PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
    PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
    else -> "Unavailable"
}

@Composable
private fun DayyanGameBoosterApp(
    readStatus: () -> DeviceStatus,
    launchCodm: () -> Unit
) {
    var status by remember { mutableStateOf(readStatus()) }
    var selectedTab by rememberSaveable { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(5_000)
            status = readStatus()
        }
    }

    Scaffold(
        containerColor = AppBackground,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0D1420),
                contentColor = TextSecondary,
                tonalElevation = 0.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                val tabs = listOf(
                    Triple("Home", Icons.Filled.Dashboard, 0),
                    Triple("Network", Icons.Filled.Wifi, 1),
                    Triple("Game", Icons.Filled.SportsEsports, 2),
                    Triple("About", Icons.Filled.Info, 3)
                )
                tabs.forEach { (label, icon, index) ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Mint,
                            selectedTextColor = Mint,
                            indicatorColor = PanelRaised,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AppHeader()
            when (selectedTab) {
                0 -> HomeScreen(
                    status = status,
                    onRefresh = { status = readStatus() },
                    onLaunchCodm = launchCodm,
                    onOpenNetworkTab = { selectedTab = 1 }
                )
                1 -> NetworkScreen(status = status, onRefresh = { status = readStatus() })
                2 -> GameScreen(status = status, onLaunchCodm = launchCodm)
                else -> AboutScreen(status = status)
            }
            Text(
                "DAYYAN GAME BOOSTER  •  EARLY BUILD 0.1.0",
                color = Color(0xFF65758B),
                fontSize = 10.sp,
                letterSpacing = 1.2.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun AppHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Mint),
            contentAlignment = Alignment.Center
        ) {
            Text("D", color = AppBackground, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
        Column(Modifier.padding(start = 11.dp)) {
            Text("DAYYAN", color = Mint, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
            Text("GAME BOOSTER", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Panel)
                .padding(horizontal = 10.dp, vertical = 7.dp)
        ) {
            Text("TECNO READY", color = TextSecondary, fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    status: DeviceStatus,
    onRefresh: () -> Unit,
    onLaunchCodm: () -> Unit,
    onOpenNetworkTab: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = PanelRaised)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("CALL OF DUTY: MOBILE", color = Mint, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
                Text("Your game.\nYour device. Your data.", color = TextPrimary, fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (status.codmInstalled) "CODM appears to be installed on this phone." else "CODM was not detected. Install the game before using the launch shortcut.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Button(
                    onClick = onLaunchCodm,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = AppBackground)
                ) {
                    Icon(Icons.Filled.SportsEsports, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  OPEN CALL OF DUTY MOBILE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("DEVICE OVERVIEW")
            Spacer(Modifier.weight(1f))
            OutlinedButton(
                onClick = onRefresh,
                shape = RoundedCornerShape(11.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 11.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh status", modifier = Modifier.size(15.dp), tint = Mint)
                Text(" Refresh", color = TextPrimary, fontSize = 11.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "BATTERY",
                value = if (status.batteryPercent in 0..100) "${status.batteryPercent}%" else "N/A",
                subtitle = status.batteryState,
                icon = Icons.Filled.BatteryChargingFull,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "BATTERY TEMP",
                value = status.batteryTemperature,
                subtitle = "Battery sensor only",
                icon = Icons.Filled.Thermostat,
                modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(
                title = "THERMAL STATUS",
                value = status.thermalStatus,
                subtitle = "Android system status",
                icon = Icons.Filled.Thermostat,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "DISPLAY MODE",
                value = if (status.displayRefreshRate > 0f) "${status.displayRefreshRate.toInt()} Hz" else "N/A",
                subtitle = "Screen refresh rate, not FPS",
                icon = Icons.Filled.Dashboard,
                modifier = Modifier.weight(1f)
            )
        }

        InfoPanel(
            title = "NETWORK",
            value = status.networkType,
            detail = status.internetStatus,
            actionLabel = "VIEW NETWORK",
            onAction = onOpenNetworkTab
        )
        Text("DEVICE", color = Mint, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
        Text(status.deviceName, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(status.androidVersion, color = TextSecondary, fontSize = 12.sp)
        Text(
            "Readings refresh while this screen is open. A display refresh-rate reading is not the same as CODM's rendered FPS.",
            color = TextSecondary,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun NetworkScreen(status: DeviceStatus, onRefresh: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("NETWORK MONITOR")
        Text("A connection summary from Android. This screen does not run a speed test or promise lower ping.", color = TextSecondary, fontSize = 13.sp)
        MetricCard(
            title = "ACTIVE CONNECTION",
            value = status.networkType,
            subtitle = status.internetStatus,
            icon = Icons.Filled.Wifi,
            modifier = Modifier.fillMaxWidth()
        )
        InfoPanel(
            title = "CONNECTION CHECK",
            value = if (status.internetStatus == "Internet validated") "Internet validated" else "Check connection",
            detail = status.internetStatus,
            actionLabel = "REFRESH STATUS",
            onAction = onRefresh
        )
        TipCard(
            title = "BEFORE A MATCH",
            items = listOf(
                "Pause large downloads and app updates.",
                "Use a stable connection and avoid switching networks mid-match.",
                "A strong signal does not guarantee low latency; network routing and congestion also matter."
            )
        )
        Text("No location, contacts, or account permissions are requested by this starter version.", color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun GameScreen(status: DeviceStatus, onLaunchCodm: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("GAME PREPARATION")
        Text("These are safe preparation tips. Android does not give ordinary apps permission to force GPU clocks, clear every other app, or unlock hidden CODM frame-rate limits.", color = TextSecondary, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Text("RECOMMENDED CHECKLIST", color = Mint, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                ChecklistLine("Close downloads and unused streaming apps.")
                ChecklistLine("Keep the phone uncovered and avoid charging during demanding play if it gets hot.")
                ChecklistLine("Use the graphics and frame-rate options available inside CODM.")
                ChecklistLine("Reduce graphics settings if you notice sustained heat or unstable performance.")
                ChecklistLine("Keep the game and Android system updated through official updates.")
            }
        }
        MetricCard(
            title = "ANDROID THERMAL STATUS",
            value = status.thermalStatus,
            subtitle = "Reported by Android; not a CPU/GPU temperature",
            icon = Icons.Filled.Thermostat,
            modifier = Modifier.fillMaxWidth()
        )
        MetricCard(
            title = "AVAILABLE SYSTEM RAM",
            value = String.format(Locale.US, "%.1f GB", status.availableRamGb),
            subtitle = String.format(Locale.US, "of %.1f GB total reported", status.totalRamGb),
            icon = Icons.Filled.Dashboard,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = onLaunchCodm,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(13.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = AppBackground)
        ) {
            Icon(Icons.Filled.SportsEsports, contentDescription = null)
            Text("  LAUNCH CODM", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AboutScreen(status: DeviceStatus) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("ABOUT THIS APP")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Dayyan Game Booster", color = TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Version 0.1.0 • Native Android starter", color = Mint, fontSize = 12.sp)
                Text("A companion dashboard for CODM players. It reports selected information exposed by Android and gives practical game-preparation guidance.", color = TextSecondary, fontSize = 13.sp)
            }
        }
        TipCard(
            title = "MEASUREMENT LIMITS",
            items = listOf(
                "Battery temperature is not CPU or GPU temperature.",
                "Display Hz describes the screen refresh mode; it does not measure CODM FPS.",
                "Thermal status is Android's overall thermal state and may be unavailable on some devices.",
                "Network type and validation are not a ping or throughput measurement."
            )
        )
        TipCard(
            title = "WHAT THIS VERSION DOES NOT DO",
            items = listOf(
                "It does not claim to increase FPS or guarantee smoother gameplay.",
                "It does not modify CODM files, game memory, or device firmware.",
                "It does not force CPU/GPU frequencies or bypass Android restrictions.",
                "Cloud accounts, online sync, automatic background alerts, and live FPS overlay are not included yet."
            )
        )
        Text("Device: ${status.deviceName}", color = TextSecondary, fontSize = 12.sp)
        Text(status.androidVersion, color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Mint, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Mint, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(width = 5.dp, height = 1.dp))
                Text(title, color = TextSecondary, fontSize = 9.sp, letterSpacing = 0.8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(value, color = TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = TextSecondary, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun InfoPanel(
    title: String,
    value: String,
    detail: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Mint, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
            Text(value, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = TextSecondary, fontSize = 12.sp)
            OutlinedButton(onClick = onAction, shape = RoundedCornerShape(10.dp)) {
                Text(actionLabel, color = TextPrimary, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun TipCard(title: String, items: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Mint, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            items.forEach { item ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Box(Modifier.padding(top = 5.dp).size(6.dp).clip(CircleShape).background(Mint))
                    Text(item, color = TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun ChecklistLine(text: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.padding(top = 4.dp).size(8.dp).clip(CircleShape).background(Warning))
        Text(text, color = TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
